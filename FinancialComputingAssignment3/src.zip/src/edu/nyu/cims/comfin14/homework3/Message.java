package edu.nyu.cims.comfin14.homework3;

public interface Message {

}
